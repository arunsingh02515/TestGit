# Inspired from

https://github.com/petehunt/react-webpack-template but for Angular

# how to use

* `npm install`
* `npm start`
