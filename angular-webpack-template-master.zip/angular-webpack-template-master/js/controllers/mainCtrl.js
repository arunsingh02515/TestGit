// var angular = require('angular');

module.exports = function($scope) {
  $scope.firstName = 'John';
  $scope.lastName = 'Doe';
};
